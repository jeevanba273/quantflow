"""
Market data fetching and processing module.
"""

from .fetcher import MarketData

__all__ = ['MarketData']